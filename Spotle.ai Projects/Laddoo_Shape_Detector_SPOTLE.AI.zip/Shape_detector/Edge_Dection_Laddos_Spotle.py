#Installing necessary packages
#Computer Vision library
import cv2
#ImageProcessing library
from PIL import Image

#Input image path
input_file = r'./Input_image.jpeg'
#Output image path
output_file = r'./Output_image.jpeg'
#Optimized image path
optimized_file = r'./Optimized_image.jpeg'

#redefining the output image and optimized image
output_filename = 'Output_image.jpeg'
optimized_filename = 'Optimized_image.jpeg'

#Displaying Input Image
image = Image.open(input_file)
image.show()

#Reading Input image
img = cv2.imread(input_file)

#Convert the Input Image to Greyscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#Blur the gray Image to remove the whiten/ non-significant parts of image
blurred = cv2.GaussianBlur(gray, (11, 11), 0)
#Using the Canny Detector to detect the edges the object 
canny = cv2.Canny(blurred, 30, 150)
#Finding the contours in above image
contours, hierarchy = cv2.findContours(canny, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
#Inscribing contours on original input image
img = cv2.drawContours(img, contours, -1, (0, 255, 0), 2)

#Displaying the Output image
cv2.imwrite(output_filename, img)
final =Image.open(output_file)
final.show()

#Repeating the above steps for getting better results
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(gray, (11, 11), 0)
canny = cv2.Canny(blurred, 30, 90)
contours, hierarchy = cv2.findContours(canny.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
image = cv2.drawContours(img, contours, -1, (0, 255, 0), 2)

#Displaying the final Optimized Output image
cv2.imwrite(optimized_filename, img)
final1 = Image.open(optimized_file)
final1.show()